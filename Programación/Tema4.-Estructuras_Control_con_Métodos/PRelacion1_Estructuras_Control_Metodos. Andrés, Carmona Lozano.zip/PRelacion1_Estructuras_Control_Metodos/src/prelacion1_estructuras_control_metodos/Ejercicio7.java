/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prelacion1_estructuras_control_metodos;

/**
 *
 * @author usuario
 */
public class Ejercicio7 {
    public void multiplesOfFive(){
        
        for(int i = 0; i <= 100; i++){
            if (i % 5 != 0){
                System.out.println(i);
            }
        }
    }
}
