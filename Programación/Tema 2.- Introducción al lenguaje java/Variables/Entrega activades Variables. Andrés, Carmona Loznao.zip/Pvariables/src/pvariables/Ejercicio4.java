/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvariables;

/**
 *
 * @author usuario
 */
public class Ejercicio4 {
    public static void eurosPesetas(){
        int euros = 300;
        double pesetas = 166.387;
        double resultado;
        
        resultado = (double)euros * pesetas;
        System.out.println("El resultado de 300 euros en pesetas es el siguiente: "+resultado);
    }
    
}
