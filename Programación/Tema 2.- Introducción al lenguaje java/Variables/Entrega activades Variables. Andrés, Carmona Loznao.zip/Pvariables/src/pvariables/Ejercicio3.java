/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvariables;

/**
 *
 * @author usuario
 */
public class Ejercicio3 {
    public static void Datos(){
        String nombre = "Andres Carmona Lozano";
        String direccion = "Calle caballo 8";
        int telefono = 666666666;
        
        System.out.println(nombre+"\n"+direccion+"\n"+telefono);
    }
}
