/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvariables;

/**
 *
 * @author usuario
 */
public class Ejercicio2 {
   public static void Nombre(){
        String nombre = "Andres Carmona Lozano";
        System.out.println(nombre);
    }
}
