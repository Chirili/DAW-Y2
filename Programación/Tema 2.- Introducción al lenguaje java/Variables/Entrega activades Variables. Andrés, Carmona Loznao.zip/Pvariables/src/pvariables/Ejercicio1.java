/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pvariables;

/**
 *
 * @author usuario
 */
public class Ejercicio1 {
    public static void Operaciones(){
    int x = 144;
    int y = 999;
    
    double resultado;
    resultado = x + y;
    System.out.println("La suma de x e y es igual a: "+resultado);
    resultado = x - y;
    System.out.println("La resta de x e y es igual a: "+resultado);
    resultado = x * y;
    System.out.println("La multiplicacion de x e y es igual a: "+resultado);
    resultado = (double)x / y;
    System.out.println("La division de x e y es igual a: "+resultado);
    
    }
}
