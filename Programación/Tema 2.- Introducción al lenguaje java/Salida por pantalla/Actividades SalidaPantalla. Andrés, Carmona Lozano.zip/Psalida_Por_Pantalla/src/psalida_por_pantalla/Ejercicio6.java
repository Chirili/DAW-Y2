package psalida_por_pantalla;

public class Ejercicio6 {
    public void Piramide() {
        /*
        *
        * Escribe un programa que pinte por pantalla una pirámide rellena a base de asteriscos.
        * La base de la pirámide debe estar formada por 9 asteriscos
        *
        * */
        System.out.println("    *");
        System.out.println("   ***");
        System.out.println("  *****");
        System.out.println(" *******");
        System.out.println("*********");
    }
}