package psalida_por_pantalla;

public class Ejercicio2 {
    /*
     * Modifica el programa anterior para que además se muestre tu dirección y tu número deteléfono.
     * Asegúrate de que los datos se muestran en líneas separadas.
     * */
    public void Direccion() {
        System.out.println("Calle caballo, 8º");
        System.out.println("612345678");
    }
}
