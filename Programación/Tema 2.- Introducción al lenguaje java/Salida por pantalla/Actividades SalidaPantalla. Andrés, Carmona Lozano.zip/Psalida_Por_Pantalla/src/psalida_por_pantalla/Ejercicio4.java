package psalida_por_pantalla;

public class Ejercicio4 {
    public void horario() {
        /*
         *
         * Escribe un programa que muestre tu horario de clase.
         * Puedes usar espacios o tabuladorespara alinear el texto.
         *
         * */
        System.out.println("\t\t\t\t\t\t\tHorario");
        System.out.println("\tHoras\t\tLunes\tMartes\tMiercoles\tJueves\tViernes");
        System.out.println("16:10-17:10\t\tPROG\tPROG");
        System.out.println("17:10-18:10\t\tPROG\tPROG\tPROG");
        System.out.println("18:10-19:10\t\t\t\tPROG\tPROG");
        System.out.println("19:30-20:30\t\t\t\tPROG");
        System.out.println("20:30-21:30\t\t\t\tDAW");
        System.out.println("21:30-22:30\t\t\t\tDAW");
    }
}

