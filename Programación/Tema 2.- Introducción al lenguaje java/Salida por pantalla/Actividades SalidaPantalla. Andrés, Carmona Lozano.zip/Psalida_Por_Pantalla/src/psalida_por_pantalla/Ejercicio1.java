package psalida_por_pantalla;

public class Ejercicio1 {
    public void nombre() {
        /*
         * Escribe un programa que muestre tu nombre por pantalla.
         *
         * */
        System.out.println("Andrés");
    }

}

