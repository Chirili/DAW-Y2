package psalida_por_pantalla;

public class Ejercicio7 {
    public void piramideHueca() {
        /*
        *
        * Igual que el programa anterior, pero esta vez la pirámide estará hueca (se debe verúnicamente el contorno hecho con asteriscos).
        *
        * */
        System.out.println("    *");
        System.out.println("   * *");
        System.out.println("  *   *");
        System.out.println(" *     *");
        System.out.println("*********");
    }
}