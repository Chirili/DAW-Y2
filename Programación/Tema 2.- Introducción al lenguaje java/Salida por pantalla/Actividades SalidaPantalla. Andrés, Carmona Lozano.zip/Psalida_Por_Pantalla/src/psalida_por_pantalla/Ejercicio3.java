package psalida_por_pantalla;

public class Ejercicio3 {
    public void palabrasIngles() {
        /*

         * Escribe un programa que muestre por pantalla 10 palabras en inglés junto a su correspondiente traducción al castellano.
         * Las palabras deben estar distribuidas en dos columnas yalineadas a la izquierda.
         * Pista: Se puede insertar un tabulador mediante \t
         *
         * */
        System.out.println("1-\tred\trojo");
        System.out.println("2-\tpet\tmascota");
        System.out.println("3-\tnumber\tnumero");
        System.out.println("4-\tlive\tvivir");
        System.out.println("5-\tscreen\tpantalla");
        System.out.println("6-\tprogram\tprograma");
        System.out.println("7-\tLEFT\tizquierda");
        System.out.println("8-\tright\tderecha");
        System.out.println("9-\tword\tpalabra");
        System.out.println("10-\twrite\tescribe");
    }
}