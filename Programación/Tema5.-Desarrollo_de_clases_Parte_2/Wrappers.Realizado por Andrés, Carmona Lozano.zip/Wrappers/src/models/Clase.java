/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author usuario
 */
public class Clase {
    int dato;
    public int metodox(){
        Double d = new Double(this.dato* 1.1);
        return d.intValue();
    }
}
